<?php
/**
 * Plugin Name: Custom Recent Posts REST Endpoint
 * Description: Adds GET /wp-json/custom/v1/recent-posts returning the 5 most
 *              recent published posts (id, title, date, excerpt, permalink).
 * Type: mu-plugin (drop into wp-content/mu-plugins/)
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('rest_api_init', 'custom_v1_register_recent_posts_route');

function custom_v1_register_recent_posts_route()
{
    register_rest_route(
        'custom/v1',
        '/recent-posts',
        array(
            'methods'             => WP_REST_Server::READABLE, // GET
            'callback'            => 'custom_v1_recent_posts_handler',
            'permission_callback' => '__return_true',          // public read-only data
        )
    );
}

function custom_v1_recent_posts_handler(WP_REST_Request $request)
{
    $query = new WP_Query(array(
        'post_type'           => 'post',
        'post_status'         => 'publish',
        'posts_per_page'      => 5,
        'no_found_rows'       => true,
        'ignore_sticky_posts' => true,
    ));

    $items = array();
    foreach ($query->posts as $post) {
        $items[] = array(
            'id'        => (int) $post->ID,
            'title'     => get_the_title($post),
            'date'      => get_the_date('c', $post), // ISO 8601
            'excerpt'   => wp_strip_all_tags(get_the_excerpt($post)),
            'permalink' => get_permalink($post),
        );
    }

    return new WP_REST_Response($items, 200);
}
