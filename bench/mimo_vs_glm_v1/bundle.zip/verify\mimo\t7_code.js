'use strict';

const RETRY_ATTEMPTS = 3;
const BASE_DELAY_MS = 1000;
const TIMEOUT_MS = 10000;
const MAX_TOTAL_DELAY_MS = 10000; // cap backoff so retries don't hang forever

/**
 * Fetch a URL and return its body parsed as JSON.
 *
 * Retries up to `RETRY_ATTEMPTS` times on failure with exponential
 * backoff (1s, 2s, 4s) between attempts, and aborts each request after
 * `TIMEOUT_MS`.
 *
 * @param {string} url
 * @param {AbortSignal} [signal]
 * @returns {Promise<unknown>} parsed JSON
 */
async function fetchJson(url, signal) {
  let lastError;

  for (let attempt = 1; attempt <= RETRY_ATTEMPTS; attempt++) {
    const delay = attempt > 1 ? BASE_DELAY_MS * 2 ** (attempt - 1) : 0;

    if (attempt > 1) {
      await sleep(delay);
    }

    try {
      const response = await fetchWithTimeout(url, TIMEOUT_MS, signal);

      if (!response.ok) {
        let detail = '';
        try {
          detail = await response.text();
        } catch {
          /* body may already be consumed; status alone is enough */
        }
        const err = new Error(
          `Request failed with status ${response.status}: ${detail || 'unknown error'}`
        );
        err.status = response.status;
        throw err;
      }

      return await response.json();
    } catch (err) {
      lastError = err;

      if (attempt === RETRY_ATTEMPTS) {
        throw err;
      }

      // Cap the backoff so total wait never exceeds MAX_TOTAL_DELAY_MS.
      const nextDelay = Math.min(delay, MAX_TOTAL_DELAY_MS - delay);
      await sleep(nextDelay);
    }
  }

  throw lastError;
}

/**
 * Fetch with a hard timeout implemented via AbortController.
 */
async function fetchWithTimeout(url, timeoutMs, signal) {
  const controller = new AbortController();

  if (signal) {
    signal.addEventListener('abort', () => controller.abort(), { once: true });
  }

  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, { signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Sleeps for the given duration. Respects the caller's signal so an
 * aborted request doesn't keep the process alive unnecessarily.
 */
async function sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    if (signal) {
      signal.addEventListener(
        'abort',
        () => {
          clearTimeout(timer);
          reject(signal.reason || new Error('Request aborted'));
        },
        { once: true }
      );
    }
  });
}

module.exports = { fetchJson };
