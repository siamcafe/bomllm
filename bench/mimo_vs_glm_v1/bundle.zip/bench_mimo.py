#!/usr/bin/env python3
"""bench_mimo.py - MiMo side of mimo_vs_glm_bench_v1.

Calls Mac-mini Ollama /api/chat with model mimo-v26:q4 for each task prompt
(tasks.json, verbatim from spec). Records client wall time + ollama stats.
Bare call: no system prompt, no few-shot, identical prompts for both models.
Usage:
  python bench_mimo.py --warmup          # phase 1.2 connectivity "hello"
  python bench_mimo.py --only t1,t2      # run subset
  python bench_mimo.py                   # run all remaining tasks (skips done)
"""
import json
import os
import sys
import time
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
TASKS = os.path.join(HERE, "tasks.json")
RUNS = os.path.join(HERE, "runs")


def call_ollama(payload, timeout_s):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        "http://192.168.1.254:11434/api/chat", data=data, method="POST",
        headers={"Content-Type": "application/json"})
    t0 = time.perf_counter()
    r = urllib.request.urlopen(req, timeout=timeout_s)
    body = r.read().decode("utf-8", "replace")
    wall = time.perf_counter() - t0
    return r.status, wall, body


def main():
    cfg = json.load(open(TASKS, encoding="utf-8"))
    ho = cfg["harness_options"]
    os.makedirs(RUNS, exist_ok=True)

    if "--warmup" in sys.argv:
        payload = {"model": ho["model"],
                   "messages": [{"role": "user", "content": "hello"}],
                   "stream": False,
                   "options": {"num_ctx": 2048, "num_predict": 512},
                   "keep_alive": ho["keep_alive"]}
        status, wall, body = call_ollama(payload, 300)
        j = json.loads(body)
        open(os.path.join(RUNS, "warmup_hello.json"), "w", encoding="utf-8").write(
            json.dumps({"http": status, "wall_s": round(wall, 2),
                        "stats": j.get("stats", {}), "model": j.get("model"),
                        "content": j.get("message", {}).get("content", "")[:200]}, indent=2))
        print("WARMUP http=%d wall_s=%.2f eval_count=%s load_ms=%s" % (
            status, wall, j.get("stats", {}).get("eval_count"),
            j.get("stats", {}).get("load_duration")))
        return 0

    only = None
    for a in sys.argv:
        if a.startswith("--only="):
            only = set(x.strip() for x in a.split("=", 1)[1].split(","))
    if "--only" in sys.argv:
        i = sys.argv.index("--only")
        only = set(x.strip() for x in sys.argv[i + 1].split(","))

    for t in cfg["tasks"]:
        tid = t["id"]
        if only is not None and tid not in only:
            continue
        out = os.path.join(RUNS, "mimo_%s.json" % tid)
        if os.path.exists(out) and only is None:
            print("SKIP %s (exists)" % tid)
            continue
        payload = {"model": ho["model"],
                   "messages": [{"role": "user", "content": t["prompt"]}],
                   "stream": False,
                   "options": ho["options"],
                   "keep_alive": ho["keep_alive"]}
        attempt = 0
        while True:
            attempt += 1
            try:
                status, wall, body = call_ollama(payload, ho["http_timeout_s"])
                break
            except Exception as e:
                if attempt >= 2:
                    open(out, "w", encoding="utf-8").write(json.dumps(
                        {"error": repr(e), "attempt": attempt}, indent=2))
                    print("%s ERROR %r" % (tid, e))
                    body = None
                else:
                    time.sleep(3)
        if body is None:
            continue
        j = json.loads(body)
        st = {k: j.get(k) for k in ("total_duration", "load_duration",
                                    "prompt_eval_count", "prompt_eval_duration",
                                    "eval_count", "eval_duration")}
        rec = {"task": tid, "http": status, "wall_s": round(wall, 3),
               "stats": st, "prompt": t["prompt"],
               "content": j.get("message", {}).get("content", ""),
               "thinking": j.get("message", {}).get("thinking", ""),
               "done_reason": j.get("done_reason", ""),
               "attempt": attempt}
        open(out, "w", encoding="utf-8").write(json.dumps(rec, indent=2))
        open(os.path.join(RUNS, "mimo_%s_answer.txt" % tid), "w", encoding="utf-8").write(rec["content"])
        if rec["thinking"]:
            open(os.path.join(RUNS, "mimo_%s_thinking.txt" % tid), "w", encoding="utf-8").write(rec["thinking"])
        st = rec["stats"]
        print("%s http=%d wall_s=%.1f eval_tok=%s eval_ms=%s load_ms=%s done=%s content_len=%d" % (
            tid, status, wall, st.get("eval_count"), st.get("eval_duration"),
            st.get("load_duration"), rec["done_reason"], len(rec["content"])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
