#!/usr/bin/env python3
"""Summarize a CSV file of OHLCV (date, symbol, open, high, low, close, volume) data.

Outputs, per symbol:
  - average close price
  - total volume
  - the date with the highest close

Usage:
    python summarize.py data.csv
    python summarize.py data.csv --demo
"""

import argparse
import csv
import sys
from collections import defaultdict

REQUIRED_COLUMNS = ("date", "symbol", "open", "high", "low", "close", "volume")


def parse_number(value, column):
    """Parse a numeric cell; raise ValueError with a useful message otherwise."""
    if value is None or value.strip() == "":
        raise ValueError(f"empty value in column '{column}'")
    return float(value)


def read_csv(path):
    """Read and validate the input CSV, returning a list of row dicts."""
    with open(path, "r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)

        if reader.fieldnames is None:
            raise ValueError(f"file '{path}' is empty")

        missing = [col for col in REQUIRED_COLUMNS if col not in reader.fieldnames]
        if missing:
            raise ValueError(
                f"file '{path}' is missing column(s): {', '.join(missing)}"
                f"\nExpected columns: {', '.join(REQUIRED_COLUMNS)}"
            )

        rows = []
        for lineno, row in enumerate(reader, start=2):
            try:
                rows.append({
                    "date": row["date"].strip(),
                    "symbol": row["symbol"].strip(),
                    "open": parse_number(row["open"], "open"),
                    "high": parse_number(row["high"], "high"),
                    "low": parse_number(row["low"], "low"),
                    "close": parse_number(row["close"], "close"),
                    "volume": parse_number(row["volume"], "volume"),
                })
            except ValueError as exc:
                raise ValueError(f"row {lineno}: {exc}") from exc

        if not rows:
            raise ValueError(f"file '{path}' contains no data rows")
        return rows


def summarize(rows):
    """Aggregate rows by symbol into the stats needed for the report."""
    stats = defaultdict(lambda: {
        "count": 0,
        "close_sum": 0.0,
        "volume_sum": 0,
        "best_close": 0.0,
        "best_date": None,
        "first_date": None,
    })

    for row in rows:
        symbol = row["symbol"]
        entry = stats[symbol]

        if entry["first_date"] is None:
            entry["first_date"] = row["date"]

        entry["count"] += 1
        entry["close_sum"] += row["close"]
        entry["volume_sum"] += row["volume"]

        if entry["best_date"] is None or row["close"] > entry["best_close"]:
            entry["best_close"] = row["close"]
            entry["best_date"] = row["date"]

    return stats


def format_number(value):
    if value == int(value):
        return f"{int(value):,}"
    return f"{value:,.4f}"


def print_report(rows, stats):
    total_close_sum = sum(v["close_sum"] for v in stats.values())
    total_volume = sum(v["volume_sum"] for v in stats.values())

    print()
    print(f"{'Symbol':<10} {'Avg Close':>14} {'Total Volume':>16} "
          f"{'Highest Close':>14} {'Date':>12}")
    print("-" * 86)

    for symbol in sorted(stats):
        entry = stats[symbol]
        avg = entry["close_sum"] / entry["count"]
        print(f"{symbol:<10} {format_number(avg):>14} {format_number(entry['volume_sum']):>16} "
              f"{format_number(entry['best_close']):>14} {entry['best_date']:>12}")

    print("-" * 86)
    print(f"{'TOTAL':<10} {format_number(total_close_sum / len(stats)):>14} "
          f"{format_number(total_volume):>16}")
    print()


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Summarize OHLCV CSV data by symbol."
    )
    parser.add_argument("csv_file", help="path to the CSV file")
    parser.add_argument("--demo", action="store_true",
                        help="generate a sample CSV and process it instead")
    args = parser.parse_args(argv)

    try:
        if args.demo:
            rows = read_csv_from_demo()
            print("Using built-in demo data:\n")
        else:
            rows = read_csv(args.csv_file)

        stats = summarize(rows)
        print_report(rows, stats)
    except (OSError, UnicodeDecodeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("interrupted", file=sys.stderr)
        return 130
    return 0


def read_csv_from_demo():
    """Generate a small realistic sample CSV in memory."""
    sample = [
        ("2024-01-02", "AAPL", 185.00, 187.50, 183.25, 186.20, 42_000_000),
        ("2024-01-03", "AAPL", 186.50, 189.00, 185.75, 188.60, 45_500_000),
        ("2024-01-04", "AAPL", 188.25, 190.10, 187.50, 189.80, 38_200_000),
        ("2024-01-05", "AAPL", 190.00, 191.75, 188.90, 191.30, 40_100_000),
        ("2024-01-08", "MSFT", 388.00, 392.50, 386.00, 391.20, 21_000_000),
        ("2024-01-09", "MSFT", 391.50, 395.00, 390.25, 394.60, 23_500_000),
        ("2024-01-10", "MSFT", 394.00, 397.25, 393.00, 396.80, 20_400_000),
        ("2024-01-11", "MSFT", 397.00, 399.50, 396.50, 398.90, 22_800_000),
        ("2024-01-12", "AAPL", 191.00, 192.00, 190.50, 191.75, 30_000_000),
        ("2024-01-16", "AAPL", 192.50, 194.00, 191.20, 193.40, 33_000_000),
        ("2024-01-17", "MSFT", 399.00, 401.00, 398.00, 400.20, 24_000_000),
    ]
    with open("demo.csv", "w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(REQUIRED_COLUMNS)
        writer.writerows(sample)
    return read_csv("demo.csv")


if __name__ == "__main__":
    sys.exit(main())
