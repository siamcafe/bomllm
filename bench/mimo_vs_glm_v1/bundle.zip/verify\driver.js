const mod = require(process.argv[2]);
const fn = mod.fetchJsonWithRetry || mod.fetchJson;
const t0 = Date.now();
fn(process.argv[3]).then(d => {
  console.log("RESULT success", JSON.stringify(d), "elapsed_ms=" + (Date.now() - t0));
  process.exit(0);
}).catch(e => { console.log("RESULT failure:", e.message, "elapsed_ms=" + (Date.now() - t0)); process.exit(1); });
