"""Sliding-window rate limiter, thread-safe, stdlib only."""
import threading
import time
from collections import deque


class RateLimiter:
    """Sliding window rate limiter.

    Allows at most `max_requests` calls to allow() in any trailing
    window of `window_seconds`.
    """

    def __init__(self, max_requests: int, window_seconds: float):
        if max_requests < 1:
            raise ValueError("max_requests must be >= 1")
        if window_seconds <= 0:
            raise ValueError("window_seconds must be > 0")
        self._max_requests = max_requests
        self._window_seconds = float(window_seconds)
        self._timestamps = deque()  # monotonic times of allowed requests
        self._lock = threading.Lock()

    def _prune(self, now: float) -> None:
        """Drop timestamps older than the window. Caller must hold the lock."""
        cutoff = now - self._window_seconds
        while self._timestamps and self._timestamps[0] <= cutoff:
            self._timestamps.popleft()

    def allow(self) -> bool:
        """Record a request if allowed; return True if it was allowed."""
        with self._lock:
            now = time.monotonic()
            self._prune(now)
            if len(self._timestamps) < self._max_requests:
                self._timestamps.append(now)
                return True
            return False

    def wait_time(self) -> float:
        """Seconds until the next request would be allowed (0.0 if allowed now)."""
        with self._lock:
            now = time.monotonic()
            self._prune(now)
            if len(self._timestamps) < self._max_requests:
                return 0.0
            return max(0.0, self._timestamps[0] + self._window_seconds - now)


# ---------------------------- tests ----------------------------
def _test_basic_burst():
    rl = RateLimiter(max_requests=3, window_seconds=1.0)
    assert rl.allow() is True
    assert rl.allow() is True
    assert rl.allow() is True
    assert rl.allow() is False, "4th request inside window must be denied"
    assert rl.wait_time() > 0.0
    print("test_basic_burst: OK")


def _test_window_expiry():
    rl = RateLimiter(max_requests=2, window_seconds=0.3)
    assert rl.allow() and rl.allow()
    assert rl.allow() is False
    time.sleep(0.35)
    assert rl.allow() is True, "request must be allowed after the window slides"
    print("test_window_expiry: OK")


def _test_wait_time_value():
    rl = RateLimiter(max_requests=1, window_seconds=0.5)
    assert rl.wait_time() == 0.0
    assert rl.allow() is True
    wt = rl.wait_time()
    assert 0.0 < wt <= 0.5, "wait_time must be the remaining window, got %r" % wt
    time.sleep(0.1)
    assert rl.wait_time() < wt, "wait_time must decrease over time"
    print("test_wait_time_value: OK")


def _test_concurrent_access():
    """Hammer the limiter from 8 threads; within any window the number of
    granted requests must never exceed max_requests."""
    rl = RateLimiter(max_requests=10, window_seconds=0.5)
    grants = []
    grants_lock = threading.Lock()

    def worker():
        local = []
        deadline = time.monotonic() + 0.6
        while time.monotonic() < deadline:
            if rl.allow():
                local.append(time.monotonic())
            time.sleep(0.005)
        with grants_lock:
            grants.extend(local)

    threads = [threading.Thread(target=worker) for _ in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # sliding-window check: sort grant times, no window of length 0.5s
    # may contain more than 10 grants
    grants.sort()
    window = rl._window_seconds
    violations = 0
    for i, ts in enumerate(grants):
        j = i
        while j < len(grants) and grants[j] <= ts + window:
            j += 1
        if j - i > 10:
            violations += 1
    assert violations == 0, "sliding window violated %d times (%d grants)" % (violations, len(grants))
    print("test_concurrent_access: OK (%d grants from 8 threads, 0 violations)" % len(grants))


def _test_constructor_validation():
    for bad in ((0, 1.0), (1, 0.0), (-1, 1.0)):
        try:
            RateLimiter(*bad)
        except ValueError:
            pass
        else:
            raise AssertionError("expected ValueError for %r" % (bad,))
    print("test_constructor_validation: OK")


if __name__ == "__main__":
    _test_basic_burst()
    _test_window_expiry()
    _test_wait_time_value()
    _test_concurrent_access()
    _test_constructor_validation()
    print("All RateLimiter tests passed.")
