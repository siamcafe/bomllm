def deduplicate_list(items: list) -> list:
    """Return a new list with duplicates removed, preserving first-occurrence order.

    Items must be hashable. The input list is not modified.

    Args:
        items: The input list, possibly containing duplicates.

    Returns:
        A new list containing the unique items in their original order.
    """
    seen = set()
    result = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


# Test cases
if __name__ == "__main__":
    assert deduplicate_list([]) == []
    assert deduplicate_list([1, 2, 2, 3, 1]) == [1, 2, 3]
    assert deduplicate_list(["a", "b", "a", "c", "b"]) == ["a", "b", "c"]
    print("All tests passed.")
