//+------------------------------------------------------------------+
//| Simple Moving Average indicator                                  |
//| Draws an SMA of the close price on the main chart window.        |
//+------------------------------------------------------------------+
#property indicator_chart_window
#property indicator_buffers 1
#property indicator_plots   1

#property indicator_type1   DRAW_LINE
#property indicator_color1  clrDodgerBlue
#property indicator_style1  STYLE_SOLID
#property indicator_width1  2

//--- input parameters
input int InpSmaPeriod = 20; // SMA period

//--- indicator buffer
double SmaBuffer[];

//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
   if(InpSmaPeriod < 1)
     {
      Print("SMA period must be >= 1, got ", InpSmaPeriod);
      return(INIT_PARAMETERS_INCORRECT);
     }

   SetIndexBuffer(0, SmaBuffer, INDICATOR_DATA);
   ArraySetAsSeries(SmaBuffer, false);

   // do not draw the warm-up zone where the SMA is not yet defined
   PlotIndexSetInteger(0, PLOT_DRAW_BEGIN, InpSmaPeriod - 1);

   // set the label shown in the chart legend / Data Window
   PlotIndexSetString(0, PLOT_LABEL, "SMA(" + IntegerToString(InpSmaPeriod) + ")");

   IndicatorSetString(INDICATOR_SHORTNAME, "SMA(" + IntegerToString(InpSmaPeriod) + ")");

   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   if(rates_total < InpSmaPeriod)
      return(0);

   // start from the first bar that has a full window; on subsequent ticks
   // only recompute the last bar so the indicator stays cheap
   int start = (prev_calculated > 0) ? prev_calculated - 1 : InpSmaPeriod - 1;

   for(int i = start; i < rates_total && !IsStopped(); i++)
     {
      double sum = 0.0;
      for(int j = 0; j < InpSmaPeriod; j++)
         sum += close[i - j];
      SmaBuffer[i] = sum / InpSmaPeriod;
     }

   return(rates_total);
  }
//+------------------------------------------------------------------+
