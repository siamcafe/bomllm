#!/usr/bin/env bash
#
# find-recent.sh — List files modified in the last 24 hours.
#
# Usage: find-recent.sh <directory>
#
# Reports the total count, total size in MB, and a list of files
# sorted by size (descending).

set -euo pipefail

# ---------------------------------------------------------------------------
# Argument validation
# ---------------------------------------------------------------------------

usage() {
    echo "Usage: $0 <directory>" >&2
    exit 2
}

[[ $# -eq 1 ]] || usage

DIR="$1"

if [[ ! -d "$DIR" ]]; then
    echo "error: '$DIR' is not a directory" >&2
    exit 1
fi

if [[ ! -r "$DIR" ]]; then
    echo "error: cannot read directory '$DIR'" >&2
    exit 1
fi

# ---------------------------------------------------------------------------
# Gather files modified within the last 24 hours (1440 minutes)
# ---------------------------------------------------------------------------

# -print0 / xargs -0 / stat: filenames containing spaces, newlines, or
# leading dashes are handled safely.
mapfile -d '' -t entries < <(
    find "$DIR" -type f -mmin -1440 -print0 \
        | xargs -0 stat -c '%s %p' 2>/dev/null \
        | sort -k1,1nr
)

total=0
count=0

for entry in "${entries[@]}"; do
    # Skip entries stat() could not read (e.g. permission denied).
    [[ -n "$entry" ]] || continue

    size="${entry%% *}"
    path="${entry#* }"

    total=$(( total + size ))
    count=$(( count + 1 ))
done

# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------

if (( count == 0 )); then
    echo "No files modified in the last 24 hours in '$DIR'."
    exit 0
fi

if (( total == 0 )); then
    size_mb="0.00"
else
    size_mb=$(awk -v bytes="$total" 'BEGIN { printf "%.2f", bytes / 1048576 }')
fi

echo "Directory: $DIR"
echo "Total files: $count"
echo "Total size: ${size_mb} MB (${total} bytes)"
echo

echo "Files sorted by size (descending):"
echo "----"

for entry in "${entries[@]}"; do
    [[ -n "$entry" ]] || continue

    size="${entry%% *}"
    path="${entry#* }"

    printf '%8s  %s\n' "$size" "$path"
done

exit 0
