//+------------------------------------------------------------------+
//| FormatLotSize — format a lot size with the right decimals        |
//|   lots >= 0.1  -> 2 decimal places                               |
//|   lots <  0.1  -> 3 decimal places                               |
//+------------------------------------------------------------------+
string FormatLotSize(double lots)
  {
   int digits;
   if(lots >= 0.1)
      digits = 2;   // covers both lots >= 1.0 and 0.1 <= lots < 1.0
   else
      digits = 3;

   return(DoubleToString(lots, digits));
  }

//+------------------------------------------------------------------+
//| Test script                                                      |
//+------------------------------------------------------------------+
void OnStart()
  {
   Print("FormatLotSize(1.0)    = ", FormatLotSize(1.0));      // expect 1.00
   Print("FormatLotSize(2.3456) = ", FormatLotSize(2.3456));   // expect 2.35
   Print("FormatLotSize(0.5)    = ", FormatLotSize(0.5));      // expect 0.50
   Print("FormatLotSize(0.12)   = ", FormatLotSize(0.12));     // expect 0.12
   Print("FormatLotSize(0.09)   = ", FormatLotSize(0.09));     // expect 0.090
   Print("FormatLotSize(0.076)  = ", FormatLotSize(0.076));    // expect 0.076
  }
//+------------------------------------------------------------------+
