#!/usr/bin/env bash
# Report on files modified in the last 24 hours under a directory:
# total count, total size in MB, and the files sorted by size descending.
set -u

usage() {
    echo "Usage: $0 <directory>" >&2
    exit 2
}

if [ "$#" -ne 1 ]; then
    usage
fi

dir=$1

if [ ! -e "$dir" ]; then
    echo "Error: path does not exist: $dir" >&2
    exit 1
fi
if [ ! -d "$dir" ]; then
    echo "Error: not a directory: $dir" >&2
    exit 1
fi

tmp=$(mktemp) || { echo "Error: cannot create temp file" >&2; exit 1; }
trap 'rm -f "$tmp"' EXIT

# 24h = 1440 minutes; emit "<size-bytes><TAB><path>" lines
find "$dir" -type f -mmin -1440 -printf '%s\t%p\n' >"$tmp" 2>/dev/null

count=$(wc -l <"$tmp")
count=${count// /}

if [ "$count" -eq 0 ]; then
    echo "No files modified in the last 24 hours under: $dir"
    exit 0
fi

total_mb=$(awk -F'\t' '{ s += $1 } END { printf "%.2f", s / 1024 / 1024 }' "$tmp")

echo "Recently modified files (last 24h)"
echo "Directory : $dir"
echo "Count     : $count file(s)"
echo "Total size: ${total_mb} MB"
echo
printf '%12s  %s\n' "SIZE (MB)" "FILE"
sort -t "$(printf '\t')" -k1,1rn "$tmp" | awk -F'\t' '{ printf "%12.2f  %s\n", $1 / 1024 / 1024, $2 }'
