#!/usr/bin/env python3
"""Summarize an OHLCV CSV file.

Reads a CSV with columns: date,symbol,open,high,low,close,volume
and prints: per-symbol average close price, per-symbol total volume,
and the date with the highest close (overall).

Usage: python csv_summary.py <input.csv>
Uses only the stdlib csv module.
"""
import csv
import sys


def summarize(path: str) -> None:
    per_symbol_close_sum = {}
    per_symbol_close_n = {}
    per_symbol_volume = {}
    highest_close = float("-inf")
    highest_close_date = None

    try:
        with open(path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            required = {"date", "symbol", "close", "volume"}
            if reader.fieldnames is None or not required.issubset(reader.fieldnames):
                raise ValueError(
                    "missing required columns; expected at least date,symbol,close,volume")

            for row_num, row in enumerate(reader, start=2):
                try:
                    close = float(row["close"])
                    volume = float(row["volume"])
                except (TypeError, ValueError):
                    raise ValueError("row %d: close/volume is not numeric (%r, %r)"
                                     % (row_num, row.get("close"), row.get("volume")))
                symbol = (row["symbol"] or "").strip()
                if not symbol:
                    raise ValueError("row %d: empty symbol" % row_num)

                per_symbol_close_sum[symbol] = per_symbol_close_sum.get(symbol, 0.0) + close
                per_symbol_close_n[symbol] = per_symbol_close_n.get(symbol, 0) + 1
                per_symbol_volume[symbol] = per_symbol_volume.get(symbol, 0.0) + volume

                if close > highest_close:
                    highest_close = close
                    highest_close_date = row["date"]
    except FileNotFoundError:
        sys.exit("Error: file not found: %s" % path)
    except PermissionError:
        sys.exit("Error: cannot read (permission denied): %s" % path)
    except csv.Error as e:
        sys.exit("Error: malformed CSV: %s" % e)

    if not per_symbol_close_n:
        sys.exit("Error: no data rows found in %s" % path)

    print("Per-symbol summary")
    print("------------------")
    for symbol in sorted(per_symbol_close_n):
        avg_close = per_symbol_close_sum[symbol] / per_symbol_close_n[symbol]
        total_volume = per_symbol_volume[symbol]
        print("%-10s avg_close=%.4f  total_volume=%.2f" % (symbol, avg_close, total_volume))

    print()
    print("Highest close     : %.4f" % highest_close)
    print("Date of highest   : %s" % highest_close_date)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Usage: python %s <input.csv>" % sys.argv[0])
    summarize(sys.argv[1])
