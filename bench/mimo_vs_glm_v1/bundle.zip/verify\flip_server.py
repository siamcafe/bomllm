import http.server, json, sys
class H(http.server.BaseHTTPRequestHandler):
    fails_left = int(sys.argv[2])
    def do_GET(self):
        if H.fails_left > 0:
            H.fails_left -= 1
            self.send_response(500); self.end_headers(); self.wfile.write(b"boom"); return
        body = json.dumps({"ok": True, "n": 42}).encode()
        self.send_response(200); self.send_header("Content-Type","application/json")
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def log_message(self, *a): pass
http.server.HTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
