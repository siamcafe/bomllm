from typing import Iterable


def deduplicate_list(items: list) -> list:
    """Remove duplicates from a list, preserving the original order.

    Args:
        items: A list that may contain duplicate elements.

    Returns:
        A new list with duplicate elements removed, in first-seen order.
    """
    seen: set = set()
    result: list = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


# Test cases
if __name__ == "__main__":
    assert deduplicate_list([3, 1, 2, 1, 3, 2, 4]) == [3, 1, 2, 4]
    assert deduplicate_list([]) == []
    assert deduplicate_list("banana") == ["b", "a", "n"]
