/**
 * fetchJsonWithRetry(url, opts)
 *
 * Fetches a URL and returns the response body parsed as JSON.
 * - max 3 attempts (configurable)
 * - exponential backoff: 1s, 2s, 4s
 * - 10s timeout per request (AbortController)
 * - logs each attempt
 *
 * Node 18+ (built-in fetch), no external dependencies.
 */
async function fetchJsonWithRetry(url, opts = {}) {
  const maxAttempts = opts.maxAttempts ?? 3;
  const baseDelayMs = opts.baseDelayMs ?? 1000; // 1s -> 2s -> 4s
  const timeoutMs = opts.timeoutMs ?? 10000;

  let lastError;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      console.log(`[fetch] attempt ${attempt}/${maxAttempts}: GET ${url}`);
      const res = await fetch(url, { signal: controller.signal });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status} ${res.statusText}`);
      }
      return await res.json();
    } catch (err) {
      lastError = err;
      const reason = err.name === 'AbortError' ? `timeout after ${timeoutMs}ms` : err.message;
      console.error(`[fetch] attempt ${attempt}/${maxAttempts} failed: ${reason}`);
      if (attempt < maxAttempts) {
        const delay = baseDelayMs * 2 ** (attempt - 1);
        console.log(`[fetch] retrying in ${delay}ms ...`);
        await new Promise((r) => setTimeout(r, delay));
      }
    } finally {
      clearTimeout(timer);
    }
  }

  throw new Error(`fetch failed after ${maxAttempts} attempts: ${lastError && lastError.message}`);
}

module.exports = { fetchJsonWithRetry };

// --- demo (runs only when executed directly) ---
if (require.main === module) {
  const target = process.argv[2] || 'https://httpbin.org/json';
  fetchJsonWithRetry(target)
    .then((data) => console.log('[fetch] success:', JSON.stringify(data).slice(0, 120)))
    .catch((err) => {
      console.error('[fetch] gave up:', err.message);
      process.exit(1);
    });
}
