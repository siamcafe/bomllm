"""A thread-safe sliding window rate limiter.

Requests are tracked by their arrival timestamp. Entries older than
``window_seconds`` are dropped from the window, and the window's left
edge slides with them, so a burst of requests shortens the effective
window for later requests (classic sliding-window behaviour).
"""

from collections import deque
import threading
import time


class RateLimiter:
    def __init__(self, max_requests: int, window_seconds: float) -> None:
        """
        :param max_requests: maximum number of requests allowed per window
        :param window_seconds: length of the sliding window
        """
        if max_requests <= 0:
            raise ValueError("max_requests must be positive")
        if window_seconds <= 0:
            raise ValueError("window_seconds must be positive")

        self.max_requests = max_requests
        self.window_seconds = window_seconds

        self._lock = threading.Lock()
        self._timestamps = deque()  # arrival times of requests in the window
        self._count = 0             # number of requests currently in the window
        self._window_start = time.monotonic()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def allow(self) -> bool:
        """Return ``True`` if the request is admitted, ``False`` otherwise."""
        with self._lock:
            now = time.monotonic()

            # Drop requests that have fallen out of the window and slide the
            # window's left edge so the oldest remaining request sits exactly
            # on the boundary.
            while (self._timestamps and
                   self._timestamps[0] < now - self.window_seconds):
                self._timestamps.popleft()
                self._count -= 1
                if self._timestamps:
                    self._window_start = self._timestamps[0] - self.window_seconds

            if self._count >= self.max_requests:
                # The window is full: wait for the newest request's window to
                # expire before admitting anything.
                wait = self._timestamps[-1] + self.window_seconds - now
                if wait <= 0:
                    self._count += 1
                    self._timestamps.append(now)
                    return True
                return False

            self._count += 1
            self._timestamps.append(now)
            return True

    def wait_time(self) -> float:
        """Return seconds until the next request may be admitted."""
        with self._lock:
            now = time.monotonic()
            if self._count < self.max_requests:
                return 0.0
            oldest = self._timestamps[0]
            return max(oldest + self.window_seconds - now, 0.0)

    def reset(self) -> None:
        """Discard all tracked requests and return to a fresh window."""
        with self._lock:
            self._timestamps.clear()
            self._count = 0
            self._window_start = time.monotonic()

    def __repr__(self) -> str:
        return (f"{type(self).__name__}(max_requests={self.max_requests}, "
                f"window_seconds={self.window_seconds}, "
                f"count={self._count}, waiting={self.wait_time():.3f}s)")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

import unittest


class TestRateLimiter(unittest.TestCase):
    def test_basic_allow_and_block(self):
        limiter = RateLimiter(5, 1.0)
        self.assertEqual([limiter.allow() for _ in range(5)], [True] * 5)
        self.assertEqual([limiter.allow() for _ in range(3)], [False] * 3)
        self.assertEqual(limiter.wait_time(), 0.0)

        # Capacity refills as the window slides.
        time.sleep(1.1)
        self.assertTrue(limiter.allow())
        self.assertEqual(limiter.wait_time(), 0.0)

    def test_wait_time_decreases(self):
        limiter = RateLimiter(2, 1.0)
        limiter.allow()
        limiter.allow()

        first = limiter.wait_time()
        self.assertGreater(first, 0.9)

        time.sleep(0.2)
        second = limiter.wait_time()
        self.assertLess(second, first - 0.1)

        # Exactly one second later the oldest request has expired.
        time.sleep(0.8)
        self.assertEqual(limiter.wait_time(), 0.0)

    def test_wait_time_zero_when_capacity_available(self):
        limiter = RateLimiter(100, 1.0)
        self.assertEqual(limiter.wait_time(), 0.0)
        limiter.allow()
        self.assertEqual(limiter.wait_time(), 0.0)

    def test_window_expiry_allows_new_requests(self):
        limiter = RateLimiter(2, 0.5)
        limiter.allow()
        limiter.allow()
        self.assertFalse(limiter.allow())

        time.sleep(0.55)
        self.assertTrue(limiter.allow())
        self.assertEqual(limiter.wait_time(), 0.0)

    def test_wait_time_matches_expected_deadline(self):
        limiter = RateLimiter(1, 1.0)
        limiter.allow()
        expected = limiter.wait_time()
        self.assertGreater(expected, 0.9)

        time.sleep(0.25)
        actual = limiter.wait_time()
        self.assertAlmostEqual(actual, expected - 0.25, delta=0.05)

    def test_sliding_window_shortens_effective_window(self):
        """A burst of requests should let the window start earlier."""
        limiter = RateLimiter(3, 1.0)
        limiter.allow()
        limiter.allow()
        limiter.allow()
        burst_deadline = limiter.wait_time()
        self.assertGreater(burst_deadline, 0.9)  # window full

        time.sleep(0.8)
        # The burst has partially expired: only 2 more requests fit.
        self.assertFalse(limiter.allow())
        self.assertEqual(limiter.wait_time(), 0.0)

        time.sleep(0.3)
        self.assertTrue(limiter.allow())

    def test_concurrent_access_respects_limit(self):
        limiter = RateLimiter(3, 1.0)
        results = []
        barrier = threading.Barrier(4)

        def worker() -> None:
            for _ in range(20):
                barrier.wait()
                results.append(limiter.allow())

        threads = [threading.Thread(target=worker) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(sum(results), limiter.max_requests)
        self.assertEqual(limiter.wait_time(), 0.0)

    def test_concurrent_wait_time_agreement(self):
        """Blocked threads must observe the same deadline."""
        limiter = RateLimiter(2, 1.0)
        limiter.allow()
        limiter.allow()

        barrier = threading.Barrier(8)
        observed = []

        def observer() -> None:
            barrier.wait()
            observed.append(limiter.wait_time())

        threads = [threading.Thread(target=observer) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertTrue(all(v > 0.9 for v in observed))
        # All blocked threads read the same window state.
        self.assertEqual(len(set(observed)), 1)

        time.sleep(1.1)
        self.assertEqual(limiter.wait_time(), 0.0)

    def test_concurrent_burst_after_expiry(self):
        """Once the window expires, a burst of threads must all pass."""
        limiter = RateLimiter(2, 0.2)
        limiter.allow()
        limiter.allow()

        barrier = threading.Barrier(6)
        successes = []

        def worker() -> None:
            barrier.wait()
            successes.append(limiter.allow())

        threads = [threading.Thread(target=worker) for _ in range(6)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertTrue(all(successes))

    def test_threading_lock_prevents_overcount(self):
        limiter = RateLimiter(1, 1.0)
        results = []
        barrier = threading.Barrier(100)

        def worker() -> None:
            barrier.wait()
            results.append(limiter.allow())

        threads = [threading.Thread(target=worker) for _ in range(100)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(sum(results), 1)
        self.assertEqual(limiter.wait_time(), 0.0)

    def test_reset(self):
        limiter = RateLimiter(2, 1.0)
        limiter.allow()
        limiter.allow()
        self.assertFalse(limiter.allow())

        limiter.reset()
        self.assertEqual(limiter.wait_time(), 0.0)
        self.assertTrue(limiter.allow())

    def test_invalid_parameters(self):
        with self.assertRaises(ValueError):
            RateLimiter(0, 1.0)
        with self.assertRaises(ValueError):
            RateLimiter(5, 0)
        with self.assertRaises(ValueError):
            RateLimiter(-1, 1.0)

    def test_repr(self):
        limiter = RateLimiter(5, 1.0)
        limiter.allow()
        repr(limiter)


if __name__ == "__main__":
    unittest.main()
